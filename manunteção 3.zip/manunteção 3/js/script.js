function showPage(pageId) {
  document.querySelectorAll('.container').forEach(container => {
    container.style.display = 'none';
  });
  document.getElementById(pageId).style.display = 'block';
}

function validateEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

function validatePassword(password) {
  const hasLength = password.length >= 8;
  const hasUpper = /[A-Z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const hasSpecial = /[!@#$%^&*]/.test(password);

  document.getElementById('lengthCheck').classList.toggle('valid', hasLength);
  document.getElementById('upperCheck').classList.toggle('valid', hasUpper);
  document.getElementById('numberCheck').classList.toggle('valid', hasNumber);
  document.getElementById('specialCheck').classList.toggle('valid', hasSpecial);

  return hasLength && hasUpper && hasNumber && hasSpecial;
}


document.getElementById('forgotPasswordForm').addEventListener('submit', function (e) {
  e.preventDefault();
  const email = document.getElementById('recoveryEmail').value;
  const errorElement = document.getElementById('recoveryEmailError');
  const successElement = document.getElementById('recoverySuccess');

  if (!validateEmail(email)) {
    errorElement.style.display = 'block';
    successElement.style.display = 'none';
    return;
  }

  errorElement.style.display = 'none';
  successElement.style.display = 'block';

  setTimeout(() => {
    showPage('loginPage');
  }, 2000);
});

document.getElementById('loginForm').addEventListener('submit', function (e) {

  e.preventDefault()
  const nome = document.getElementById('campoNome').value;
  const senha = document.getElementById('campoSenha').value;
  if (nome === "admin" && senha === "1234") {
    alert('login bem sucedido bem vindo');
    window.location.href = 'index2.html'
  } else if (nome === "usuario" && senha === "1234") {
    alert('Usuario ou senha incorretos');
  } else if (nome === "" && senha === "") {
    alert('Usuario ou senha incorretos');
  } else if (nome === "admin" && senha === "") {
    alert('Usuario ou senha incorretos');
  } else if (nome === "" && senha === "1234") {
    alert('Usuario ou senha incorretos');
  } else if (nome === "admin" && senha !== "1234") {
    alert('Usuario ou senha incorretos');
  } else {
    alert('usuario e senha incorretos')
  }


})









