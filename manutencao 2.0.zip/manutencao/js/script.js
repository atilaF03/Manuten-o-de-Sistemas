// Erro 1 - Função de Cálculo Corrigida
function fixCalc() {

    const num1 =  Number (document.getElementById('primeiroNumero').value);
    const num2 =  Number(document.getElementById('segundoNumero').value);
    const result = num1 + num2;
    console.log(result)
    
    const calcErrorElement = document.getElementById("calc-error");
    calcErrorElement.innerHTML = "Resultado correto: " + result;
    calcErrorElement.classList.remove("error");
    calcErrorElement.classList.add("success"); // Bônus: Adiciona feedback visual de sucesso
}

// A função fixFormValidation() foi removida por ser redundante.
// A validação foi integrada diretamente na função generateReport().

// Gerar relatório de manutenção com validação
function generateReport(event) {
    // Previne o comportamento padrão de envio do formulário (recarregar a página)
    event.preventDefault();

    const form = document.getElementById("maintenance-form");
    const formErrorElement = document.getElementById("form-error");

    // Verifica se todos os campos 'required' do formulário foram preenchidos
    if (!form.checkValidity()) {
        formErrorElement.innerHTML = "Preencha todos os campos obrigatórios!";
        formErrorElement.classList.add("error"); // Adiciona a classe de erro
        formErrorElement.classList.remove("success");
    } else {
        // Se o formulário for válido, limpa a mensagem de erro e prossegue
        formErrorElement.innerHTML = "Relatório gerado com sucesso!";
        formErrorElement.classList.remove("error");
        formErrorElement.classList.add("success");

        const date = document.getElementById("date").value;
        const description = document.getElementById("description").value;
        const responsible = document.getElementById("responsible").value;

        const report = `Relatório de Manutenção
Data: ${date}
Tipo de Manutenção: Corretiva
Descrição: ${description}
Responsável: ${responsible}`;

        // Exibe o relatório em um alerta
        alert(report);
    }
}